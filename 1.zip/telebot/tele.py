"""
Step1] Connection:
Connect ground of led to GND(pin-6) of raspberry pi connect +ve of Led to a register then connect to GPIO 2 (pin-3)
Step 2] now open your android phone install telegram on your phone( make sure your internet connection is put on and you are connected with internet)
Register your basic information and search botfather
  Type /newbot
Choose a name and unique bot username make sure your bot username ends with “…….bot”.
After doing all above steps an API token will generate. This token code will require in our python program
Step 3]
Now start your raspberry pi kit and open a python script write the following codes in the script.


"""

import time, datetime
import RPi.GPIO as GPIO
import telepot
from telepot.loop import MessageLoop
led=2
now = datetime.datetime.now()
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(led, GPIO.OUT)
GPIO.output(led, 0) 
def action(msg):
    chat_id = msg['chat']['id']
    command = msg['text']
    print 'Received: %s' % command
      if 'on' in command:
          message = "Turned on led"  
         GPIO.output(led, 1)    
        telegram_bot.sendMessage (chat_id, message)
     if 'off' in command:
        message = "Turned off led "
        GPIO.output(led, 0)
        telegram_bot.sendMessage (chat_id, message)
telegram_bot = telepot.Bot('673602566:AAHPyBxAC_xE53MVXXQiAgcM_w3dZo38dqo’)
print (telegram_bot.getMe())
MessageLoop(telegram_bot, action).run_as_thread()
print 'Up and Running....'
while 1:
    time.sleep(10)

"""
now open terminal and type    
$sudo apt-get install python-pip
this will install python packages for using pip
now install telepot by using pip  
$sudo pip install telepot
step 5]
-Run the program in raspberry pi
$ python tele.py
-Open your bot in telegram app on your phone
And run following commands: To on and off
/start 		(pi will receives message /start in terminal)
on		(to on led)
off		(to off led)
"""


	
""" If above doesnt works """
import time, datetime 
import RPi.GPIO as GPIO 
import telepot 
from telepot.loop import MessageLoop 
green = 6 
yellow = 13 
red = 19 
blue = 26 
now = datetime.datetime.now() 
GPIO.setmode(GPIO.BCM) 
GPIO.setwarnings(False) 
##LED Blue 
GPIO.setup(blue, GPIO.OUT) 
GPIO.output(blue, 0) #Off initially 
#LED Yellow 
GPIO.setup(yellow, GPIO.OUT) 
GPIO.output(yellow, 0) #Off initially 
#LED Red 
GPIO.setup(red, GPIO.OUT) 
GPIO.output(red, 0) #Off initially 
#LED green 
GPIO.setup(green, GPIO.OUT) 
GPIO.output(green, 0) #Off initially 
def action(msg): 
	chat_id = msg['chat']['id']
	command = msg['text'] 
	print ('Received: %s' % command) 
	if 'on' in command: 
		message = "on" 
	if 'blue' in command: 
		message = message + "blue " 
		GPIO.output(blue, 1) 
	if 'yellow' in command: 
		message = message + "yellow " 
		GPIO.output(yellow, 1) 
	if 'red' in command: 
		message = message + "red " 
		GPIO.output(red, 1) 
	if 'green' in command: 
		message = message + "green " 
		GPIO.output(green, 1) 
	if 'all' in command: 
		message = message + "all " 
		GPIO.output(blue, 1) 
		GPIO.output(yellow, 1) 
		GPIO.output(red, 1) 
		GPIO.output(green, 1) 
	message = message + "light(s)" 
	telegram_bot.sendMessage (chat_id, message) 
	if 'off' in command: 
		message = "off " 
	if 'blue' in command: 
		message = message + "blue " 
		GPIO.output(blue, 0) 
	if 'yellow' in command: 
		message = message + "yellow " 
		GPIO.output(yellow, 0) 
	if 'red' in command: 
		message = message + "red " 
		GPIO.output(red, 0) 
	if 'green' in command: 
		message = message + "green " 
		GPIO.output(green, 0) 
	if 'all' in command: 
		message = message + "all " 
		GPIO.output(blue, 0) 
		GPIO.output(yellow, 0) 
		GPIO.output(red, 0) 
		GPIO.output(green, 0) 
	
	message = message + "light(s)" 
	telegram_bot.sendMessage (chat_id, message)
	telegram_bot = telepot.Bot(‘ACCESS KEY’) 
	print (telegram_bot.getMe()) 
	MessageLoop(telegram_bot, action).run_as_thread() 
	print ('Up and Running....') 
	while 1: 
	time.sleep(10)







